# KINGPIN 5.0 (Auto Bet & Predictor Engine)

Complete standalone project with frontend dashboard and recovered backend server.

---

## 🚀 How to Run

1. **Start the server**:
   ```bash
   node server.js
   ```
   *(or `npm start`)*

2. **Open in Browser**:
   ```
   http://localhost:3000
   ```

---

## 🔑 Access Keys

- **Master Super-User Key**:
  ```
  KP500-ADMIN-SUPER-USER0-99999
  ```
- **Regular User Key**:
  Any 25-character formatted key (e.g. `ABCDE-12345-FGHIJ-67890-KLMNO`) unlocks standard single-account mode.

---

## 📂 Project Structure

```
├── index.html          # Main SPA Dashboard & Client Logic (Bugs fixed)
├── server.js           # Recovered Express REST API & Socket.IO Real-Time Engine
├── css/
│   └── autobet.css     # Dark theme styles & responsive design
├── js/
│   └── socket.io.js    # Socket.IO v4.8.3 client library
├── package.json        # Dependencies & scripts
└── node_modules/       # express & socket.io installed
```
