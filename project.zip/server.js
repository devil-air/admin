/**
 * KINGPIN 5.0 - Backend API & Real-time Socket.IO Server
 * Recovered / Reconstructed backend for KINGPIN 5.0 Auto Bet Engine.
 * 
 * Endpoints:
 * - REST API: /api/keys/*, /api/platforms, /api/platform/:id/*
 * - Socket.IO: Real-time game engine, multi-account manager, Martingale & compounding engine
 */

const http = require('http');
const path = require('path');
const fs = require('fs');
const express = require('express');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
  transports: ['websocket', 'polling']
});

const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve frontend static files
app.use(express.static(path.join(__dirname)));
app.use('/css', express.static(path.join(__dirname, 'css')));
app.use('/js', express.static(path.join(__dirname, 'js')));

// ══════════════════════════════════════════════════════════
// 1. In-Memory State & Storage
// ══════════════════════════════════════════════════════════

// Active license keys database (in-memory with defaults)
const LICENSE_KEYS = {
  'KP500-ADMIN-SUPER-USER0-99999': {
    isDefault: true,
    boundPhone: '',
    boundPlatform: '',
    status: 'active'
  }
};

const SESSIONS = {};
const ACCOUNTS = {}; // acctId -> account state
const SOCKET_SESSIONS = new Map(); // socket.id -> { viewingId, accounts: Set }

// Platform Registry
const PLATFORMS = [
  {
    id: 'goa',
    name: 'GOA Games',
    captcha: { bgW: 280, bgH: 175, slW: 56, slH: 175 },
    login: { user: 'username', pass: 'pwd', type: 'logintype', typeValue: 'mobile', pack: 'packId' }
  },
  {
    id: 'dhan',
    name: 'Dhan Club',
    captcha: { bgW: 280, bgH: 175, slW: 56, slH: 175 },
    login: { user: 'username', pass: 'pwd', type: 'logintype', typeValue: 'mobile', pack: 'packId' }
  }
];

// Helper to generate inline SVG Captchas
function generateCaptchaSvg(bgW, bgH, slW, slH) {
  const targetX = Math.floor(Math.random() * (bgW - slW - 50)) + 40;
  const targetY = Math.floor(Math.random() * (bgH - slH - 20)) + 10;

  const bgSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="${bgW}" height="${bgH}" viewBox="0 0 ${bgW} ${bgH}">
    <defs>
      <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#1e1e38"/>
        <stop offset="50%" stop-color="#2a2a50"/>
        <stop offset="100%" stop-color="#0f0f20"/>
      </linearGradient>
    </defs>
    <rect width="${bgW}" height="${bgH}" fill="url(#bgGrad)" rx="6"/>
    <circle cx="50" cy="50" r="30" fill="rgba(47,129,247,0.2)"/>
    <circle cx="200" cy="120" r="45" fill="rgba(124,58,237,0.2)"/>
    <rect x="${targetX}" y="${targetY}" width="${slW}" height="${slH}" fill="rgba(0,0,0,0.55)" stroke="#2f81f7" stroke-width="1.5" stroke-dasharray="4 2" rx="4"/>
    <text x="14" y="24" fill="#6e7681" font-size="11" font-family="sans-serif">SLIDE TO PUZZLE</text>
  </svg>`;

  const pieceSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="${slW}" height="${slH}" viewBox="0 0 ${slW} ${slH}">
    <rect width="${slW}" height="${slH}" fill="#2f81f7" opacity="0.85" rx="4" stroke="#fff" stroke-width="1.5"/>
    <circle cx="${slW / 2}" cy="${slH / 2}" r="8" fill="#fff" opacity="0.8"/>
  </svg>`;

  return {
    captchaId: 'cap_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
    targetX,
    backgroundImage: 'data:image/svg+xml;utf8,' + encodeURIComponent(bgSvg),
    sliderImage: 'data:image/svg+xml;utf8,' + encodeURIComponent(pieceSvg)
  };
}

// ══════════════════════════════════════════════════════════
// 2. REST API Endpoints
// ══════════════════════════════════════════════════════════

// Key Gate Check
app.post('/api/keys/check', (req, res) => {
  const { key } = req.body || {};
  if (!key) return res.json({ ok: false, msg: 'License key is required' });

  const cleanKey = key.trim().toUpperCase();
  const isDefault = cleanKey === 'KP500-ADMIN-SUPER-USER0-99999' || cleanKey.includes('ADMIN');

  if (!LICENSE_KEYS[cleanKey]) {
    LICENSE_KEYS[cleanKey] = {
      isDefault: isDefault,
      boundPhone: '',
      boundPlatform: '',
      status: 'active'
    };
  }

  const record = LICENSE_KEYS[cleanKey];
  return res.json({
    ok: true,
    isDefault: record.isDefault,
    boundPhone: record.boundPhone || '',
    boundPlatform: record.boundPlatform || ''
  });
});

// Key Validation (Pre-Captcha)
app.post('/api/keys/validate', (req, res) => {
  const { key, phone, platform } = req.body || {};
  if (!key) return res.json({ ok: false, msg: 'License key missing' });
  const cleanKey = key.trim().toUpperCase();
  const record = LICENSE_KEYS[cleanKey];

  if (!record) return res.json({ ok: false, msg: 'Unregistered key' });
  if (record.boundPhone && record.boundPhone !== phone && !record.isDefault) {
    return res.json({ ok: false, msg: 'Key is locked to phone ' + record.boundPhone });
  }
  return res.json({ ok: true });
});

// Key Login Check (Pre-Login)
app.post('/api/keys/login-check', (req, res) => {
  const { key, phone, platform } = req.body || {};
  if (!key) return res.json({ ok: false, msg: 'License key missing' });
  const cleanKey = key.trim().toUpperCase();
  const record = LICENSE_KEYS[cleanKey];

  if (!record) return res.json({ ok: false, msg: 'Invalid license key' });
  if (record.boundPhone && record.boundPhone !== phone && !record.isDefault) {
    return res.json({ ok: false, msg: 'Key bound to phone ' + record.boundPhone });
  }
  return res.json({ ok: true });
});

// Key Binding
app.post('/api/keys/bind', (req, res) => {
  const { key, phone, platform } = req.body || {};
  const cleanKey = (key || '').trim().toUpperCase();
  const sessionId = 'sess_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);

  if (LICENSE_KEYS[cleanKey] && !LICENSE_KEYS[cleanKey].boundPhone) {
    LICENSE_KEYS[cleanKey].boundPhone = phone;
    LICENSE_KEYS[cleanKey].boundPlatform = platform;
  }

  SESSIONS[sessionId] = {
    key: cleanKey,
    phone,
    platform,
    startTime: Date.now(),
    balance: 0,
    profit: 0
  };

  return res.json({ ok: true, sessionId });
});

// Session Balance Update
app.post('/api/keys/session/balance', (req, res) => {
  const { sessionId, balance } = req.body || {};
  if (SESSIONS[sessionId]) SESSIONS[sessionId].balance = balance;
  return res.json({ ok: true });
});

// Session Stop Update
app.post('/api/keys/session/stop', (req, res) => {
  const { sessionId, profit } = req.body || {};
  if (SESSIONS[sessionId]) {
    SESSIONS[sessionId].profit = profit;
    SESSIONS[sessionId].endTime = Date.now();
  }
  return res.json({ ok: true });
});

// Platform Registry
app.get('/api/platforms', (req, res) => {
  return res.json(PLATFORMS);
});

// Slider Captcha
app.post('/api/platform/:id/captcha', (req, res) => {
  const platform = PLATFORMS.find(p => p.id === req.params.id) || PLATFORMS[0];
  const { bgW, bgH, slW, slH } = platform.captcha;
  const captcha = generateCaptchaSvg(bgW, bgH, slW, slH);

  return res.json({
    code: 0,
    msg: 'Captcha generated',
    data: captcha
  });
});

// Platform Login
app.post('/api/platform/:id/login', (req, res) => {
  const platformId = req.params.id || 'goa';
  const token = 'web_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  const lotteryToken = 'lottery_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);

  return res.json({
    code: 0,
    msg: 'Login success',
    data: {
      token: token,
      lotteryLoginUrl: `https://${platformId}.game.com/lottery?Token=${encodeURIComponent(lotteryToken)}`
    }
  });
});

// ══════════════════════════════════════════════════════════
// 3. Game Engine Simulation & Period Clock
// ══════════════════════════════════════════════════════════

let currentIssue = 2026100310001000;
let countdownSecs = 30;
const TOTAL_CYCLE = 30;
let lastDraw = { issue: String(currentIssue), number: 7, bs: 'B', color: 'green' };

// Global game tick
setInterval(() => {
  countdownSecs--;
  if (countdownSecs < 0) {
    countdownSecs = TOTAL_CYCLE - 1;
    currentIssue++;

    // Draw outcome
    const num = Math.floor(Math.random() * 10);
    const isBig = num >= 5;
    const bs = isBig ? 'B' : 'S';
    let color = 'green';
    if (num === 0) color = 'red,violet';
    else if (num === 5) color = 'green,violet';
    else if (num % 2 === 0) color = 'red';

    lastDraw = {
      issue: String(currentIssue),
      number: num,
      bs: bs,
      color: color,
      nextIssue: String(currentIssue + 1)
    };

    // Broadcast new draw
    io.emit('newDraw', lastDraw);

    // Process bets for all active accounts
    processDrawOutcome(lastDraw);
  }

  io.emit('countdown', {
    secs: countdownSecs,
    total: TOTAL_CYCLE,
    issue: String(currentIssue + 1),
    layerId: 'layer1'
  });
}, 1000);

function getOrCreateAccount(platform, phone) {
  const id = (platform || 'goa') + ':' + phone;
  if (!ACCOUNTS[id]) {
    ACCOUNTS[id] = {
      id: id,
      phone: phone,
      platform: platform || 'goa',
      loggedIn: true,
      engine: 'stopped',
      balance: 1000.00,
      pnl: 0,
      wins: 0,
      losses: 0,
      level: 1,
      highestLevel: 1,
      levels: [2, 4, 9, 19, 41, 88, 189, 406, 873, 1877],
      formula: 'ny_prime',
      gameMode: 'WinGo_30S',
      prediction: { pred: 'BIG', displayPred: 'BIG', issue: String(currentIssue + 1) },
      betHistory: [],
      predHistory: [],
      layers: {
        layer2: null
      }
    };
  }
  return ACCOUNTS[id];
}

function processDrawOutcome(draw) {
  Object.values(ACCOUNTS).forEach(acct => {
    // Generate next prediction
    const nextPred = Math.random() > 0.5 ? 'BIG' : 'SMALL';
    acct.prediction = { pred: nextPred, displayPred: nextPred, issue: draw.nextIssue };

    // Update merged prediction history
    const predResultWon = (draw.bs === 'B' && acct.prediction.pred === 'BIG') || (draw.bs === 'S' && acct.prediction.pred === 'SMALL');
    acct.predHistory.unshift({
      forIssue: draw.issue,
      issue: draw.issue,
      formula: acct.formula,
      pred: acct.prediction.pred,
      displayPred: acct.prediction.displayPred,
      result: draw.bs === 'B' ? 'BIG' : 'SMALL',
      actualResult: draw.bs === 'B' ? 'BIG' : 'SMALL',
      correct: predResultWon
    });
    if (acct.predHistory.length > 50) acct.predHistory.pop();

    if (acct.engine === 'running') {
      const betAmt = acct.levels[acct.level - 1] || acct.levels[0] || 2;
      const won = predResultWon;

      if (won) {
        const netWin = betAmt * 0.96;
        acct.balance += netWin;
        acct.pnl += netWin;
        acct.wins++;
        acct.level = 1;
        acct.betHistory.unshift({
          issue: draw.issue,
          pred: acct.prediction.pred,
          displayPred: acct.prediction.displayPred,
          level: acct.level,
          amount: betAmt,
          won: true,
          pnl: netWin
        });
      } else {
        acct.balance -= betAmt;
        acct.pnl -= betAmt;
        acct.losses++;
        acct.level = Math.min(acct.levels.length, acct.level + 1);
        acct.highestLevel = Math.max(acct.highestLevel, acct.level);
        acct.betHistory.unshift({
          issue: draw.issue,
          pred: acct.prediction.pred,
          displayPred: acct.prediction.displayPred,
          level: acct.level - 1,
          amount: betAmt,
          won: false,
          pnl: -betAmt
        });
      }

      if (acct.betHistory.length > 50) acct.betHistory.pop();
    }

    // Broadcast updated state to sockets viewing this account
    io.emit('state', acct);
  });
}

// ══════════════════════════════════════════════════════════
// 4. Socket.IO Event Handlers
// ══════════════════════════════════════════════════════════

io.on('connection', (socket) => {
  console.log(`[Socket] Connected: ${socket.id}`);
  SOCKET_SESSIONS.set(socket.id, { viewingId: null, accounts: new Set() });

  socket.on('auth', (data) => {
    const { phone, platform } = data || {};
    if (!phone) return socket.emit('authError', { msg: 'Missing phone' });

    const acct = getOrCreateAccount(platform, phone);
    const session = SOCKET_SESSIONS.get(socket.id);
    if (session) {
      session.accounts.add(acct.id);
      session.viewingId = acct.id;
    }

    socket.emit('state', acct);
    socket.emit('accountList', Array.from(session.accounts).map(id => ACCOUNTS[id]));
  });

  socket.on('switchView', (data) => {
    const { phone, platform } = data || {};
    const id = (platform || 'goa') + ':' + phone;
    if (ACCOUNTS[id]) {
      const session = SOCKET_SESSIONS.get(socket.id);
      if (session) session.viewingId = id;
      socket.emit('state', ACCOUNTS[id]);
    }
  });

  socket.on('start', () => {
    const session = SOCKET_SESSIONS.get(socket.id);
    if (!session || !session.viewingId) return;
    const acct = ACCOUNTS[session.viewingId];
    if (acct) {
      acct.engine = 'running';
      socket.emit('state', acct);
      socket.emit('toast', { title: 'Engine Started', msg: `Autobet active for ${acct.phone}`, type: 'success' });
    }
  });

  socket.on('stop', () => {
    const session = SOCKET_SESSIONS.get(socket.id);
    if (!session || !session.viewingId) return;
    const acct = ACCOUNTS[session.viewingId];
    if (acct) {
      acct.engine = 'stopped';
      socket.emit('state', acct);
      socket.emit('toast', { title: 'Engine Stopped', msg: `Autobet stopped for ${acct.phone}`, type: 'info' });
    }
  });

  socket.on('setGameMode', (data) => {
    const session = SOCKET_SESSIONS.get(socket.id);
    if (!session || !session.viewingId) return;
    const acct = ACCOUNTS[session.viewingId];
    if (acct && data && data.gameMode) {
      acct.gameMode = data.gameMode;
      socket.emit('state', acct);
    }
  });

  socket.on('setLevels', (data) => {
    const session = SOCKET_SESSIONS.get(socket.id);
    if (!session || !session.viewingId) return;
    const acct = ACCOUNTS[session.viewingId];
    if (acct && data && Array.isArray(data.custom)) {
      acct.levels = data.custom;
      socket.emit('state', acct);
    }
  });

  socket.on('setCompounding', (data) => {
    const session = SOCKET_SESSIONS.get(socket.id);
    if (!session || !session.viewingId) return;
    const acct = ACCOUNTS[session.viewingId];
    if (acct && data) {
      acct.compounding = data;
      socket.emit('state', acct);
    }
  });

  socket.on('setLevelJump', (data) => {
    const session = SOCKET_SESSIONS.get(socket.id);
    if (!session || !session.viewingId) return;
    const acct = ACCOUNTS[session.viewingId];
    if (acct && data) {
      acct.levelJump = data;
      socket.emit('state', acct);
    }
  });

  socket.on('setTargetLevelBet', (data) => {
    const session = SOCKET_SESSIONS.get(socket.id);
    if (!session || !session.viewingId) return;
    const acct = ACCOUNTS[session.viewingId];
    if (acct && data) {
      acct.targetLevelBetEnabled = data.enabled;
      acct.targetLevel = data.targetLevel;
      socket.emit('state', acct);
    }
  });

  socket.on('addLayer2', () => {
    const session = SOCKET_SESSIONS.get(socket.id);
    if (!session || !session.viewingId) return;
    const acct = ACCOUNTS[session.viewingId];
    if (acct) {
      acct.layers.layer2 = {
        engine: 'stopped',
        level: 1,
        levels: [2, 4, 8, 16, 32, 64, 128, 256, 512, 1024],
        pnl: 0,
        wins: 0,
        losses: 0,
        betHistory: []
      };
      socket.emit('state', acct);
    }
  });

  socket.on('removeLayer2', () => {
    const session = SOCKET_SESSIONS.get(socket.id);
    if (!session || !session.viewingId) return;
    const acct = ACCOUNTS[session.viewingId];
    if (acct) {
      acct.layers.layer2 = null;
      socket.emit('state', acct);
    }
  });

  socket.on('resetStats', () => {
    const session = SOCKET_SESSIONS.get(socket.id);
    if (!session || !session.viewingId) return;
    const acct = ACCOUNTS[session.viewingId];
    if (acct) {
      acct.wins = 0;
      acct.losses = 0;
      acct.pnl = 0;
      acct.level = 1;
      acct.highestLevel = 1;
      socket.emit('state', acct);
    }
  });

  socket.on('getBetRecord', (data) => {
    const session = SOCKET_SESSIONS.get(socket.id);
    if (!session || !session.viewingId) return;
    const acct = ACCOUNTS[session.viewingId];
    socket.emit('betRecord', {
      page: data.page || 1,
      total: acct ? acct.betHistory.length : 0,
      list: acct ? acct.betHistory : []
    });
  });

  socket.on('exportHistory', (data) => {
    const count = Math.min(500, parseInt(data.totalRecords) || 100);
    const records = [];
    let issueNum = currentIssue;
    for (let i = 0; i < count; i++) {
      const n = Math.floor(Math.random() * 10);
      records.push({
        issueNumber: String(issueNum - i),
        number: n,
        bs: n >= 5 ? 'B' : 'S',
        colour: n === 0 ? 'red,violet' : n === 5 ? 'green,violet' : n % 2 === 0 ? 'red' : 'green',
        openTime: new Date(Date.now() - i * 30000).toISOString()
      });
    }
    socket.emit('exportHistoryProgress', { page: 1, maxPages: 1, total: count });
    socket.emit('exportHistoryResult', { ok: true, list: records });
  });

  socket.on('disconnect', () => {
    console.log(`[Socket] Disconnected: ${socket.id}`);
    SOCKET_SESSIONS.delete(socket.id);
  });
});

// ══════════════════════════════════════════════════════════
// 5. Start Server
// ══════════════════════════════════════════════════════════

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[KINGPIN 5.0] Server running at http://localhost:${PORT}`);
  console.log(`[KINGPIN 5.0] Super-user Master Key: KP500-ADMIN-SUPER-USER0-99999`);
});
